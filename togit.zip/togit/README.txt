Script to automatically set up Ghostwriter with pre-loaded report template (Original credit to University of Florida).

Credentials:
administrator:7JcNRwoXjAXhZcq4jospk93wDGX0UyJs